/****************************************************************************
** Meta object code from reading C++ file 'ft_interface.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "ft_interface.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ft_interface.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MyEventLoop_t {
    QByteArrayData data[3];
    char stringdata0[29];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MyEventLoop_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MyEventLoop_t qt_meta_stringdata_MyEventLoop = {
    {
QT_MOC_LITERAL(0, 0, 11), // "MyEventLoop"
QT_MOC_LITERAL(1, 12, 15), // "quitWithTimeout"
QT_MOC_LITERAL(2, 28, 0) // ""

    },
    "MyEventLoop\0quitWithTimeout\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyEventLoop[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void MyEventLoop::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MyEventLoop *_t = static_cast<MyEventLoop *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->quitWithTimeout(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject MyEventLoop::staticMetaObject = {
    { &QEventLoop::staticMetaObject, qt_meta_stringdata_MyEventLoop.data,
      qt_meta_data_MyEventLoop,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MyEventLoop::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyEventLoop::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MyEventLoop.stringdata0))
        return static_cast<void*>(const_cast< MyEventLoop*>(this));
    return QEventLoop::qt_metacast(_clname);
}

int MyEventLoop::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QEventLoop::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_QOAuth__Ft_Interface_t {
    QByteArrayData data[16];
    char stringdata0[247];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QOAuth__Ft_Interface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QOAuth__Ft_Interface_t qt_meta_stringdata_QOAuth__Ft_Interface = {
    {
QT_MOC_LITERAL(0, 0, 20), // "QOAuth::Ft_Interface"
QT_MOC_LITERAL(1, 21, 4), // "init"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 7), // "cleanup"
QT_MOC_LITERAL(4, 35, 17), // "requestToken_data"
QT_MOC_LITERAL(5, 53, 12), // "requestToken"
QT_MOC_LITERAL(6, 66, 20), // "requestTokenRSA_data"
QT_MOC_LITERAL(7, 87, 15), // "requestTokenRSA"
QT_MOC_LITERAL(8, 103, 16), // "accessToken_data"
QT_MOC_LITERAL(9, 120, 11), // "accessToken"
QT_MOC_LITERAL(10, 132, 19), // "accessTokenRSA_data"
QT_MOC_LITERAL(11, 152, 14), // "accessTokenRSA"
QT_MOC_LITERAL(12, 167, 20), // "accessResources_data"
QT_MOC_LITERAL(13, 188, 15), // "accessResources"
QT_MOC_LITERAL(14, 204, 23), // "accessResourcesRSA_data"
QT_MOC_LITERAL(15, 228, 18) // "accessResourcesRSA"

    },
    "QOAuth::Ft_Interface\0init\0\0cleanup\0"
    "requestToken_data\0requestToken\0"
    "requestTokenRSA_data\0requestTokenRSA\0"
    "accessToken_data\0accessToken\0"
    "accessTokenRSA_data\0accessTokenRSA\0"
    "accessResources_data\0accessResources\0"
    "accessResourcesRSA_data\0accessResourcesRSA"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QOAuth__Ft_Interface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   84,    2, 0x08 /* Private */,
       3,    0,   85,    2, 0x08 /* Private */,
       4,    0,   86,    2, 0x08 /* Private */,
       5,    0,   87,    2, 0x08 /* Private */,
       6,    0,   88,    2, 0x08 /* Private */,
       7,    0,   89,    2, 0x08 /* Private */,
       8,    0,   90,    2, 0x08 /* Private */,
       9,    0,   91,    2, 0x08 /* Private */,
      10,    0,   92,    2, 0x08 /* Private */,
      11,    0,   93,    2, 0x08 /* Private */,
      12,    0,   94,    2, 0x08 /* Private */,
      13,    0,   95,    2, 0x08 /* Private */,
      14,    0,   96,    2, 0x08 /* Private */,
      15,    0,   97,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void QOAuth::Ft_Interface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Ft_Interface *_t = static_cast<Ft_Interface *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->init(); break;
        case 1: _t->cleanup(); break;
        case 2: _t->requestToken_data(); break;
        case 3: _t->requestToken(); break;
        case 4: _t->requestTokenRSA_data(); break;
        case 5: _t->requestTokenRSA(); break;
        case 6: _t->accessToken_data(); break;
        case 7: _t->accessToken(); break;
        case 8: _t->accessTokenRSA_data(); break;
        case 9: _t->accessTokenRSA(); break;
        case 10: _t->accessResources_data(); break;
        case 11: _t->accessResources(); break;
        case 12: _t->accessResourcesRSA_data(); break;
        case 13: _t->accessResourcesRSA(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject QOAuth::Ft_Interface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QOAuth__Ft_Interface.data,
      qt_meta_data_QOAuth__Ft_Interface,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QOAuth::Ft_Interface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QOAuth::Ft_Interface::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QOAuth__Ft_Interface.stringdata0))
        return static_cast<void*>(const_cast< Ft_Interface*>(this));
    return QObject::qt_metacast(_clname);
}

int QOAuth::Ft_Interface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
