/****************************************************************************
** Meta object code from reading C++ file 'ut_interface.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "ut_interface.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ut_interface.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QOAuth__Ut_Interface_t {
    QByteArrayData data[24];
    char stringdata0[390];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QOAuth__Ut_Interface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QOAuth__Ut_Interface_t qt_meta_stringdata_QOAuth__Ut_Interface = {
    {
QT_MOC_LITERAL(0, 0, 20), // "QOAuth::Ut_Interface"
QT_MOC_LITERAL(1, 21, 4), // "init"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 7), // "cleanup"
QT_MOC_LITERAL(4, 35, 11), // "constructor"
QT_MOC_LITERAL(5, 47, 11), // "consumerKey"
QT_MOC_LITERAL(6, 59, 14), // "setConsumerKey"
QT_MOC_LITERAL(7, 74, 14), // "consumerSecret"
QT_MOC_LITERAL(8, 89, 17), // "setConsumerSecret"
QT_MOC_LITERAL(9, 107, 14), // "requestTimeout"
QT_MOC_LITERAL(10, 122, 17), // "setRequestTimeout"
QT_MOC_LITERAL(11, 140, 5), // "error"
QT_MOC_LITERAL(12, 146, 17), // "requestToken_data"
QT_MOC_LITERAL(13, 164, 12), // "requestToken"
QT_MOC_LITERAL(14, 177, 16), // "accessToken_data"
QT_MOC_LITERAL(15, 194, 11), // "accessToken"
QT_MOC_LITERAL(16, 206, 27), // "createParametersString_data"
QT_MOC_LITERAL(17, 234, 22), // "createParametersString"
QT_MOC_LITERAL(18, 257, 21), // "inlineParameters_data"
QT_MOC_LITERAL(19, 279, 16), // "inlineParameters"
QT_MOC_LITERAL(20, 296, 21), // "setRSAPrivateKey_data"
QT_MOC_LITERAL(21, 318, 16), // "setRSAPrivateKey"
QT_MOC_LITERAL(22, 335, 29), // "setRSAPrivateKeyFromFile_data"
QT_MOC_LITERAL(23, 365, 24) // "setRSAPrivateKeyFromFile"

    },
    "QOAuth::Ut_Interface\0init\0\0cleanup\0"
    "constructor\0consumerKey\0setConsumerKey\0"
    "consumerSecret\0setConsumerSecret\0"
    "requestTimeout\0setRequestTimeout\0error\0"
    "requestToken_data\0requestToken\0"
    "accessToken_data\0accessToken\0"
    "createParametersString_data\0"
    "createParametersString\0inlineParameters_data\0"
    "inlineParameters\0setRSAPrivateKey_data\0"
    "setRSAPrivateKey\0setRSAPrivateKeyFromFile_data\0"
    "setRSAPrivateKeyFromFile"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QOAuth__Ut_Interface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x08 /* Private */,
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    0,  130,    2, 0x08 /* Private */,
       9,    0,  131,    2, 0x08 /* Private */,
      10,    0,  132,    2, 0x08 /* Private */,
      11,    0,  133,    2, 0x08 /* Private */,
      12,    0,  134,    2, 0x08 /* Private */,
      13,    0,  135,    2, 0x08 /* Private */,
      14,    0,  136,    2, 0x08 /* Private */,
      15,    0,  137,    2, 0x08 /* Private */,
      16,    0,  138,    2, 0x08 /* Private */,
      17,    0,  139,    2, 0x08 /* Private */,
      18,    0,  140,    2, 0x08 /* Private */,
      19,    0,  141,    2, 0x08 /* Private */,
      20,    0,  142,    2, 0x08 /* Private */,
      21,    0,  143,    2, 0x08 /* Private */,
      22,    0,  144,    2, 0x08 /* Private */,
      23,    0,  145,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void QOAuth::Ut_Interface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Ut_Interface *_t = static_cast<Ut_Interface *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->init(); break;
        case 1: _t->cleanup(); break;
        case 2: _t->constructor(); break;
        case 3: _t->consumerKey(); break;
        case 4: _t->setConsumerKey(); break;
        case 5: _t->consumerSecret(); break;
        case 6: _t->setConsumerSecret(); break;
        case 7: _t->requestTimeout(); break;
        case 8: _t->setRequestTimeout(); break;
        case 9: _t->error(); break;
        case 10: _t->requestToken_data(); break;
        case 11: _t->requestToken(); break;
        case 12: _t->accessToken_data(); break;
        case 13: _t->accessToken(); break;
        case 14: _t->createParametersString_data(); break;
        case 15: _t->createParametersString(); break;
        case 16: _t->inlineParameters_data(); break;
        case 17: _t->inlineParameters(); break;
        case 18: _t->setRSAPrivateKey_data(); break;
        case 19: _t->setRSAPrivateKey(); break;
        case 20: _t->setRSAPrivateKeyFromFile_data(); break;
        case 21: _t->setRSAPrivateKeyFromFile(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject QOAuth::Ut_Interface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QOAuth__Ut_Interface.data,
      qt_meta_data_QOAuth__Ut_Interface,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QOAuth::Ut_Interface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QOAuth::Ut_Interface::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QOAuth__Ut_Interface.stringdata0))
        return static_cast<void*>(const_cast< Ut_Interface*>(this));
    return QObject::qt_metacast(_clname);
}

int QOAuth::Ut_Interface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
