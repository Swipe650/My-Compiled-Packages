/****************************************************************************
** Meta object code from reading C++ file 'interface.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "interface.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'interface.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QOAuth__Interface_t {
    QByteArrayData data[17];
    char stringdata0[198];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QOAuth__Interface_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QOAuth__Interface_t qt_meta_stringdata_QOAuth__Interface = {
    {
QT_MOC_LITERAL(0, 0, 17), // "QOAuth::Interface"
QT_MOC_LITERAL(1, 18, 13), // "_q_parseReply"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 14), // "QNetworkReply*"
QT_MOC_LITERAL(4, 48, 5), // "reply"
QT_MOC_LITERAL(5, 54, 16), // "_q_setPassphrase"
QT_MOC_LITERAL(6, 71, 2), // "id"
QT_MOC_LITERAL(7, 74, 10), // "QCA::Event"
QT_MOC_LITERAL(8, 85, 5), // "event"
QT_MOC_LITERAL(9, 91, 18), // "_q_handleSslErrors"
QT_MOC_LITERAL(10, 110, 16), // "QList<QSslError>"
QT_MOC_LITERAL(11, 127, 6), // "errors"
QT_MOC_LITERAL(12, 134, 11), // "consumerKey"
QT_MOC_LITERAL(13, 146, 14), // "consumerSecret"
QT_MOC_LITERAL(14, 161, 14), // "requestTimeout"
QT_MOC_LITERAL(15, 176, 15), // "ignoreSslErrors"
QT_MOC_LITERAL(16, 192, 5) // "error"

    },
    "QOAuth::Interface\0_q_parseReply\0\0"
    "QNetworkReply*\0reply\0_q_setPassphrase\0"
    "id\0QCA::Event\0event\0_q_handleSslErrors\0"
    "QList<QSslError>\0errors\0consumerKey\0"
    "consumerSecret\0requestTimeout\0"
    "ignoreSslErrors\0error"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QOAuth__Interface[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       5,   42, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   29,    2, 0x08 /* Private */,
       5,    2,   32,    2, 0x08 /* Private */,
       9,    2,   37,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 7,    6,    8,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 10,    4,   11,

 // properties: name, type, flags
      12, QMetaType::QByteArray, 0x00095103,
      13, QMetaType::QByteArray, 0x00095103,
      14, QMetaType::UInt, 0x00095103,
      15, QMetaType::Bool, 0x00095103,
      16, QMetaType::Int, 0x00095001,

       0        // eod
};

void QOAuth::Interface::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Interface *_t = static_cast<Interface *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->d_func()->_q_parseReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 1: _t->d_func()->_q_setPassphrase((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QCA::Event(*)>(_a[2]))); break;
        case 2: _t->d_func()->_q_handleSslErrors((*reinterpret_cast< QNetworkReply*(*)>(_a[1])),(*reinterpret_cast< const QList<QSslError>(*)>(_a[2]))); break;
        default: ;
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        Interface *_t = static_cast<Interface *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QByteArray*>(_v) = _t->consumerKey(); break;
        case 1: *reinterpret_cast< QByteArray*>(_v) = _t->consumerSecret(); break;
        case 2: *reinterpret_cast< uint*>(_v) = _t->requestTimeout(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->ignoreSslErrors(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->error(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        Interface *_t = static_cast<Interface *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setConsumerKey(*reinterpret_cast< QByteArray*>(_v)); break;
        case 1: _t->setConsumerSecret(*reinterpret_cast< QByteArray*>(_v)); break;
        case 2: _t->setRequestTimeout(*reinterpret_cast< uint*>(_v)); break;
        case 3: _t->setIgnoreSslErrors(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QOAuth::Interface::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QOAuth__Interface.data,
      qt_meta_data_QOAuth__Interface,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QOAuth::Interface::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QOAuth::Interface::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QOAuth__Interface.stringdata0))
        return static_cast<void*>(const_cast< Interface*>(this));
    return QObject::qt_metacast(_clname);
}

int QOAuth::Interface::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
